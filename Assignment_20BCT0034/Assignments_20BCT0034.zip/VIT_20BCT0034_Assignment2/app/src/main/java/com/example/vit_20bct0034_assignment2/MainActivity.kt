package com.example.vit_20bct0034_assignment2

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.DialogInterface
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.annotation.RequiresApi
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.vit_20bct0034_assignment2.ui.theme.VIT_20BCT0034_Assignment2Theme
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter

class MainActivity : ComponentActivity() {
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            VIT_20BCT0034_Assignment2Theme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    Main()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@RequiresApi(Build.VERSION_CODES.O)
@Composable
fun Main(){
    var name by remember { mutableStateOf("") }
    var mobile by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var gender by remember { mutableStateOf("") }
    var dob by remember { mutableStateOf(LocalDate.now()) }
    var date by remember { mutableStateOf(LocalDate.now()) }
    var time by remember { mutableStateOf(LocalTime.now()) }
    var bloodGroup by remember { mutableStateOf("") }
    val context = LocalContext.current

    ModalNavigationDrawer(drawerContent = { /*TODO*/ }) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            topBar = {
                TopAppBar(title = {
                    Text(text = "Blood Bank App")
                },
                )
            }
        ) { paddingValues ->
            LazyColumn(modifier = Modifier
                .padding(paddingValues)
                .fillMaxSize(),
                verticalArrangement = Arrangement.Top,
                horizontalAlignment = Alignment.CenterHorizontally,
                userScrollEnabled = true) {
                item {
                    val itemModifier = Modifier
                        .fillMaxWidth()
                        .padding(30.dp, 5.dp)
                    Text(text = "Schedule Donation", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    TextField(value = name, onValueChange = {name = it}, modifier = itemModifier, label = {Text("Name")})
                    Button(onClick = {
                        val a = DatePickerDialog(context)
                        a.setOnDateSetListener { _, year, monthOfYear, dayOfMonth ->
                            dob = LocalDate.of(year, monthOfYear+1, dayOfMonth)
                        }
                        a.show()
                    }, modifier = itemModifier) {
                        Text("Date of Birth: $dob")
                    }
                    TextField(value = mobile, onValueChange = {mobile = it}, modifier = itemModifier, label = {Text("Mobile Number")})
                    TextField(value = email, onValueChange = {email = it}, modifier = itemModifier, label = {Text("Email Id")})
                    TextField(value = gender, onValueChange = {gender = it}, modifier = itemModifier, label = {Text("Gender")})
                    TextField(value = bloodGroup, onValueChange = {bloodGroup = it}, modifier = itemModifier, label = {Text("Blood Group")})
                    Button(onClick = {val a = DatePickerDialog(context)
                        a.setOnDateSetListener { _, year, monthOfYear, dayOfMonth ->
                            date = LocalDate.of(year, monthOfYear+1, dayOfMonth)
                        }
                        a.show()
                    }, modifier = itemModifier) {
                        Text("Date of Appointment: $date")
                    }
                    Button(onClick = {
                        TimePickerDialog(context,
                            { _, hourOfDay, minute ->
                                time = LocalTime.of(hourOfDay, minute)
                            },
                            time.hour, time.minute, false
                        ).show()
                    }, modifier = itemModifier) {
                        Text("Time of Appointment: ${time.format(DateTimeFormatter.ofPattern("hh mm a"))}")
                    }
                    Button(onClick = {
                        android.app.AlertDialog.Builder(context)
                            .setTitle("Details")
                            .setMessage(
                                "Name: $name\n" +
                                        "Date of Birth: $date\n" +
                                        "Mobile Number: $mobile\n" +
                                        "Email Id: $email\n" +
                                        "Gender: $gender\n" +
                                        "Blood Group: $bloodGroup\n" +
                                        "Date of Appointment: $date\n" +
                                        "Time of Appointment: ${time.format(DateTimeFormatter.ofPattern("hh mm a"))}"
                            )
                            .setNegativeButton("Close"){ _: DialogInterface, _:Int -> }
                            .create()
                            .show()
                    }, modifier = itemModifier) {
                        Text(text = "Submit")
                    }
                }

            }
        }
    }
}