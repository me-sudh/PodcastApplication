package com.example.vit_20bct0034_assignment3

import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.vit_20bct0034_assignment3.ui.theme.VIT_20BCT0034_Assignment3Theme

//main Boilerplate
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            VIT_20BCT0034_Assignment3Theme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    Main(applicationContext)
                }
            }
        }
    }
}

//Main Function for handling database and navigation
@Composable
fun Main(applicationContext: Context){
    //database
    val db = Room.databaseBuilder(
        applicationContext,
        MyDatabase::class.java, "myapp"
    ).allowMainThreadQueries().build()
    val dao = db.entryDao()

    //navigation
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = "mainScreen"){
        composable("mainScreen"){
            MainScreen( {navController.navigate("create")},
                {navController.navigate("read")})
        }

        composable("create"){
            Create( {navController.navigate("mainScreen")},
                {
                    navController.navigate("read"){
                        popUpTo("mainScreen")}
                },
                {dao.insertAll(it)}
                )
        }

        composable("read"){
            Read( {navController.navigate("mainScreen")},
                {
                    navController.navigate("create"){
                        popUpTo("mainScreen")}
                },
                {dao.findByLocation(it)},{dao.findByName(it)}
                )
        }

    }
}

//composable functions
@Composable
fun MainScreen(
    navigateToCreate: () -> Unit,
    navigateToRead: () -> Unit
){
    Column(modifier = Modifier.fillMaxSize().padding(100.dp),
    verticalArrangement = Arrangement.Top,
    horizontalAlignment = Alignment.CenterHorizontally) {
        Button(onClick = navigateToCreate ) {
            Text(text = "Enter data")
        }
        Button(onClick = navigateToRead ) {
            Text(text = "Retrieve Data")
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Create(
    navigateToMain: () -> Unit,
    navigateToRead: () -> Unit,
    dbEntry: (new: Entry) -> Unit
){
    val context = LocalContext.current
    Column(modifier = Modifier.fillMaxSize().padding(10.dp),
        verticalArrangement = Arrangement.Top,
        horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = "Add to the database")
        var name by remember { mutableStateOf("") }
        var location by remember { mutableStateOf("") }
        TextField(value = name, onValueChange = {name = it}, label = { Text(text = "Name")})
        TextField(value = location, onValueChange = {location = it}, label = { Text(text = "Location")})
        Button(onClick = {
            if(name == "" || location == ""){
                Toast.makeText(context, "Neither of the fields are allowed to be empty!", Toast.LENGTH_SHORT).show()
            }
            else{
                dbEntry(Entry(name, location))
                Toast.makeText(context, "Successfully inserted", Toast.LENGTH_SHORT).show()
            }
        }) {
            Text(text = "Enter data")
        }
        Row(modifier = Modifier.fillMaxWidth().padding(10.dp),
        horizontalArrangement = Arrangement.Center) {
            Button(onClick = navigateToMain) {
                Text("Main Screen")
            }
            Button(onClick = navigateToRead) {
                Text(text = "Retrieve Data")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Read(
    navigateToMain: () -> Unit,
    navigateToCreate: () -> Unit,
    readWithLocation: (inp: String) -> String,
    readWithName: (inp: String) -> String
){
    val context = LocalContext.current
    Column(modifier = Modifier.fillMaxSize().padding(10.dp),
        verticalArrangement = Arrangement.Top,
        horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = "Retrieve data from database")
        var inp by remember {mutableStateOf("")}
        var out by remember { mutableStateOf("") }
        TextField(value = inp, onValueChange = {inp = it}, label = { Text(text = "Input")})
        Button(onClick = {
            if(inp == ""){
                Toast.makeText(context, "Input should not be empty!", Toast.LENGTH_SHORT).show()
            }
            else{
                out = readWithLocation(inp)
                Toast.makeText(context, "Retrieved Successfully", Toast.LENGTH_SHORT).show()
            }
        }) {
           Text(text = "Retrieve Using Location")
        }
        Button(onClick = {
            if(inp == ""){
                Toast.makeText(context, "Input should not be empty!", Toast.LENGTH_SHORT).show()
            }
            else{
                out = readWithName(inp)
                Toast.makeText(context, "Retrieved Successfully", Toast.LENGTH_SHORT).show()
            }
        }) {
                Text(text = "Retrieve Using Name")
        }
        Text(text = "Retrieved data: $out")
        Row(modifier = Modifier.fillMaxWidth().padding(10.dp),
        horizontalArrangement = Arrangement.Center) {
            Button(onClick = navigateToMain) {
                Text(text = "Main Screen")
            }
            Button(onClick = navigateToCreate) {
                Text(text = "Insert Data")
            }
        }
    }
}

//Database setup
@Entity
data class Entry(
    @PrimaryKey val name: String,
    val location: String
)

@Dao
interface EntryDao {
    @Query("SELECT * FROM Entry")
    fun getAll(): List<Entry>

    @Query("SELECT name FROM Entry WHERE location LIKE :inp LIMIT 1")
    fun findByLocation(inp: String): String

    @Query("SELECT location FROM Entry WHERE name LIKE :inp")
    fun findByName(inp: String): String

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(vararg entries: Entry)

    @Delete
    fun delete(entry: Entry)

}

@Database(entities = [Entry::class], version = 1)
abstract class MyDatabase : RoomDatabase() {
    abstract fun entryDao(): EntryDao
}