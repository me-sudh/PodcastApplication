package com.example.vit_20bct0034_assignment1

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.vit_20bct0034_assignment1.ui.theme.VIT_20BCT0034_Assignment1Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            VIT_20BCT0034_Assignment1Theme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    Main()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Main(){
    Card(elevation = CardDefaults.cardElevation(defaultElevation = 20.dp),
        modifier = Modifier
            .padding(10.dp)
            .fillMaxSize(),
        border = BorderStroke(2.dp, Color.Gray)
    ) {
        Column(verticalArrangement = Arrangement.Top,
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxSize()
                .padding(30.dp, 30.dp)) {
            Image(painter = painterResource(id = R.drawable.instagram_logo), contentDescription = "logo",
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(60.dp, 5.dp),
                contentScale = ContentScale.FillWidth)

            Text(text = "Sign up to see photos and videos from your friends.", fontWeight = FontWeight.Bold,
                fontSize = 20.sp, color = Color(142,140,143)
            )
            var email by remember { mutableStateOf("") }
            var name by remember { mutableStateOf("") }
            var user by remember { mutableStateOf("") }
            var pass by remember { mutableStateOf("") }
            TextField(value = email, onValueChange = {email = it}, modifier = Modifier.padding(2.dp), placeholder = {Text("Email Id")})
            TextField(value = name, onValueChange = {name = it}, modifier = Modifier.padding(2.dp), placeholder = { Text("Full Name") })
            TextField(value = user, onValueChange = {user = it}, modifier = Modifier.padding(2.dp), placeholder = { Text("Username") })
            TextField(value = pass, onValueChange = {pass = it}, modifier = Modifier.padding(2.dp), placeholder = { Text("Password") })

            Text(text = "People who use our service may have uploaded your contact information to Instagram. Learn more",
                modifier = Modifier.padding(0.dp, 10.dp))
            Text(text = "By signing up, you agree to our Terms, Privacy Policy and Cookies Policy.",
                modifier = Modifier.padding(0.dp, 10.dp))

            Button(onClick = { /*TODO*/ },
                colors = ButtonDefaults.buttonColors(Color(178,223,252,255)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(text = "Sign Up")
            }

        }
    }
}